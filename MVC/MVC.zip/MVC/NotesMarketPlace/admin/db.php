<?php
$server = "localhost";
$user = "root";
$password = "";
$database = "Notes_Marketplace";

$con = mysqli_connect($server, $user, $password, $database);

if (!$con) {
    die('Connect Error: ' . mysqli_connect_error());
}
