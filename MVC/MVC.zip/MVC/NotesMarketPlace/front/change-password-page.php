<!DOCTYPE html>
<html lang="en">

<head>

    <!--Meta tags-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0 ,user-scalable=no">

    <!--Title-->
    <title>Notes Marketplace</title>

    <!--Fevicon-->
    <link rel="icon" href="images/favicon.ico">

    <!--Google Fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">

    <!--Font-Awesome-->
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">

    <!--bootstrap css-->
    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">

    <!--Custom css-->
    <link rel="stylesheet" href="css/style.css">

    <!--Responsive css-->
    <link rel="stylesheet" href="css/responsive.css">

</head>

<body>

    <div id="home-background">
        <div id="login-with-img">
            <!--Grid-->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4 col-md-3 col-sm-2 col-1"></div>
                    <div id="logo" class="col-lg-4 col-md-6 col-sm-8 col-10 text-center">
                        <img src="images/top-logo.png" alt="White-logo" title="Website White Logo" class="img-fluid">
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-2 col-1"></div>
                    <div class="col-lg-4 col-md-3 col-sm-2 col-0"></div>
                    <div class="col-lg-4 col-md-6 col-sm-8 col-12">
                        <!--Login form -->
                        <div id="log-in">
                            <!--Form-->
                            <form>
                                <h2 class="text-center">
                                    Change Password
                                </h2>
                                <p class="text-center">
                                    Enter your new password to change your password
                                </p>
                                <div class="form-group">
                                    <label class="change-psd-label">Old password</label>
                                    <div class="reset-passowrd-eye pull-right">
                                        <img src="images/eye.png" toggle="#old-password" class="toggle-password"
                                            alt="View"> &nbsp;
                                    </div>
                                    <input type="password" class="form-control" id="old-password"
                                        placeholder="Enter your old password">
                                </div>
                                <div class="form-group">
                                    <label class="change-psd-label">New password</label>
                                    <div class="reset-passowrd-eye pull-right">
                                        <img src="images/eye.png" toggle="#new-password" class="toggle-password"
                                            alt="View"> &nbsp;
                                    </div> <input type="password" class="form-control" id="new-password"
                                        placeholder="Enter your new password">
                                </div>
                                <div class="form-group">
                                    <label class="change-psd-label">Confirm password</label>
                                    <div class="reset-passowrd-eye pull-right">
                                        <img src="images/eye.png" toggle="#confirm-password" class="toggle-password"
                                            alt="View"> &nbsp;
                                    </div> <input type="password" class="form-control" id="confirm-password"
                                        placeholder="Enter your confirm password">
                                </div>
                                <div class="general-btn">
                                    <button id="reset-passowrd-btn" type="submit"
                                        class="btn btn-primary btn-block">submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-2 col-0"></div>
                </div>
            </div>
        </div>
    </div>

    <!--jquery js-->
    <script src="js/jquery/jquery.min.js"></script>

    <!--bootstrap js-->
    <script src="js/bootstrap/bootstrap.min.js"></script>

    <!--Custom Script-->
    <script src="js/script.js"></script>

</body>

</html>