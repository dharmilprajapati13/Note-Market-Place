<!--footer-->
<footer>
    <div id="footer">
        <hr>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>Copyright &#169; <a href="https://www.tatvasoft.com/"
                            title="TatvaSoft-click here for more info">TatvaSoft </a> All rights reserved.
                    </h3>
                </div>
                <div class="col-md-6">
                    <ul class="footer-social-list">
                        <li><a href="https://www.facebook.com/TatvaSoft/"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="https://twitter.com/tatvasoft?s=20"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="https://www.linkedin.com/company/tatvasoft"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--footer end-->