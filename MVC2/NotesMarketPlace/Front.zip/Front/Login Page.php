<?php

include "db.php";

error_reporting(0);

session_start();

 if(isset($_POST['submit'])){
    $emailid=$_POST['emailid'];
    $password=$_POST['password'];
    
    $emailid=mysqli_real_escape_string($con,$emailid);
    $password=mysqli_real_escape_string($con,$password);
    
    $sql="SELECT * from users WHERE emailid='$emailid'";
    $result=mysqli_query($con,$sql);
    
    if($row = mysqli_fetch_assoc($result)){
        $useremail=$row['emailid'];
        $userpassword=$row['password'];
        $id=$row['userid'];
    }
    
    
    if($useremail===$emailid && $password===$userpassword){
        $_SESSION['userid']=$id;
        header('Location: Dashboard.php');
    }else{
        echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
    }
    
    
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
       
       
    <!-- important meta tags in html -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    
    <link rel="stylesheet" href="css/Login%20Page.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.css">
   </head>
    
    <body>
        
       <!-- Login -->
        <div class="login-box">
            <img id="img-1" src="img1/top-logo.png">
            <div class="centerdiv">
                <h1 id="header-1">Login</h1>
                <h5 id="text-1">Enter your email address and password to login</h5>
                <form action="" method="post">
                    <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" name="emailid" placeholder="Enter email" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <a href="Forget%20Password.php">Forgot Password?</a>
                    <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Password"  required>
                  </div>
                  <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label">Remember me</label>
                  </div>
                    <button type="submit" name="submit" class="btn btn-1">LOGIN</button>
                    <div class="signup-link">
                        Don't have an account? <a href="Sign%20Up.php">Sign Up</a>
                    </div>
                  </form>
            </div>
        </div>

       
    </body>
    
</html>