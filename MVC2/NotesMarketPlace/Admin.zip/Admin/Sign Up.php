<?php

include 'db.php';
error_reporting(0);

session_start();

if(isset($_POST['submit'])){
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $emailid = $_POST['emailid'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    
	if ($password == $cpassword) {
		$sql = "SELECT * FROM users WHERE emailid='$emailid'";
		$result = mysqli_query($con, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO users(roleid,firstname,lastname,emailid,password,isemailverified,createddate,isactive) VALUES(1,'$firstname','$lastname','$emailid','$password',0,NOW(),1)";
			$result = mysqli_query($con, $sql);
			if ($result) {
                   echo "<script>alert('Wow! User Registration Completed.')</script>";
                $firstname = "";
                $lastname = "";
                $emailid = "";
                $_POST['password'] = "";
                $_POST['cpassword'] = "";
                
			} else {
				echo "<script>alert('Woops! Something Wrong Went.')</script>";
			}
		} else {
			echo "<script>alert('Woops! Email Already Exists.')</script>";
		}
		
	} else {
		echo "<script>alert('Password Not Matched.')</script>";
	}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0 ,user-scalable=no">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.css">
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/Sign%20Up.css">
    <link rel="stylesheet" href="css/resposive.css">
    <title>Sign Up</title>
</head>

<body>
    <!-- Sign Up -->
    <section id="signup-box">
        <img id="img-1" src="img2/top-logo.png">
        <div class="centerdiv">
            <h1 id="header-1">Create an Account</h1>
            <h5 id="text-1">Enter your details to Sign Up</h5>
            <form action="" method="post">
                <div class="form-group">
                    <label>First Name</label>
                    <input type="text" name="firstname" class="form-control" id="exampleInputFirstName" placeholder="Enter Your First Name" value="<?php echo $firstname; ?>" required>
                </div>

                <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" name="lastname" class="form-control" id="exampleInputLastName" placeholder="Enter Your Last Name" value="<?php echo $lastname; ?>" required>
                </div>

                <div class="form-group">
                    <label>Email address</label>
                    <input type="email" name="emailid" class="form-control" id="exampleInputEmail1" placeholder="Enter email" value="<?php echo $emailid; ?>" required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Enter your Password" value="<?php echo $_POST['password']; ?>" required>
                    <span toggle="#exampleInputPassword1" class="fa fa-fw fa-eye field-new toggle-new"></span>
                </div>

                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="cpassword" class="form-control" id="exampleInputConfirmPassword1" placeholder="Re-Enter your Password" value="<?php echo $_POST['cpassword']; ?>" required>
                    <span toggle="#exampleInputConfirmPassword1" class="fa fa-fw fa-eye field-new toggle-cpass"></span>
                </div>
                <div class="form-group">
                    <button name="submit" type="submit" class="btn">SIGN UP</button>
                </div>


                <div class="login-link">
                    Already have an account? <a href="Login%20Page.php">Login</a>
                </div>

            </form>
        </div>



    </section>
    <!-- script-->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
</body>

</html>