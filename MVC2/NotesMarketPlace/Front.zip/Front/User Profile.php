<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">

    <title>Add Notes</title>

    <link rel="stylesheet" type="text/css" href="css/User%20Profile.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">
</head>

<body>

    <!-- Sticky Pages -->
    <header class="site-header">
          <div class="header-wrapper">
            <div class="logo-wrapper">

           
            <!-- Logo -->
            <a href="#" title="Site Logo" class="navbar-brand">
              <img src="img/dark-top-logo.png" id="logo">
            </a>

            </div>

            <!-- Main Menu bar -->
            <div class="navigation-wrapper">
              <nav class="main-nav">  
                 <ul class="menu-navigation">
                    <li>
                      <a href="Search%20Page.php">Search Notes</a>
                    </li>
                    <li>
                      <a href="sold-notes.php">Sell Your Notes</a>
                    </li>
                    <li>
                      <a href="FAQ.php">FAQ's</a>
                    </li>
                    <li>
                      <a href="Contact%20Us.php">Contact Us</a>
                    </li>
                    <li>
                      <button id="logout-button">Logout</button>
                    </li>
                  </ul>     
              </nav>
            </div>

          </div>
    </header> 
    <!-- End Header -->

   
    <!-- Add Notes Section-->
    <section id="add-notes">
      <div style="position: relative;">
        <img src="img/banner-with-overlay.jpg" class="banner">
        <p class="content-img">User Profile</p>
      </div>
    </section>

    <section id="add-notes-form">
        <div class="container">

            <div class="add-notes-1">
                <span class="content-top">Basic Prifile Details</span>
            </div>
              
            <div class="contact-2">
                
                <form class="form-details">

                  <div class="form">
                      
                      <div class="col-sm-6">
                    
                        <div class="form-group">
                          <label for="exampleInputFirstName">First Name *</label>
                          <input type="text" class="form-control" id="exampleInputFirstName" placeholder="Enter your first name">
                        </div>

                        <div class="form-group">
                          <label for="exampleInputEmail">Email *</label>
                          <input type="email" class="form-control" id="exampleInputEmail" placeholder="Enter your email address">
                        </div>
                      
                        <div class="form-group">
                          <label for="exampleInputGender">Gender</label>
                          <select class="form-control" id="exampleInputGender" placeholder="Select your Genter">
                            <option value="" disabled selected>Select your Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                            </select>
                        </div>
                     
                      </div>

                      <div class="col-sm-6">
                          <div class="form-group comments">
                            <label for="exampleInputLastName">Last Name *</label>
                            <input type="text" class="form-control" id="exampleInputLastName" placeholder="Enter your last name">
                          </div>
                          
                          <div class="form-group comments">
                            <label for="exampleInputDateOfBirth">Date Of Birth</label>
                            <input type="date" class="form-control" id="exampleInputDateOfBirth" placeholder="Enter your birth date">
                          </div>
                          
                          <div class="form-group comments">
                            <table>
                            <label for="exampleInputPhoneNumber">Phone Number</label>
                                <td><select class="form-control" id="exampleInputCountryCode" placeholder="+91">
                                    <option value="+91">+91</option>
                                    <option value="+92">+92</option>
                                    <option value="+1">+1</option>
                                </select>
                              </td>
                              <td><input type="number" class="form-control" id="exampleInputPhoneNumber" placeholder="Enter your phone number"></td>
                              </table>
                            </div>              
                      </div>
                      
                      <div class="col-sm-12">
                        <div class="form-comments">
                            <label for="exampleInputUploadProfilePicture">Upload Profile Picture *</label>
                            <input type="text" class="form-control" id="exampleInputUploadProfilePicture" placeholder="Upload Profile Picture">
                        </div>
                      </div>
                
                    <div class="add-notes-1">
                        <span class="content-institution-information">Address Details</span>
                    </div>
                      
                    <div class="col-sm-6">
                          <div class="form-group address details">
                              <label for="exampleInputAddressLine1">Address Line 1 *</label>
                              <input type="text" class="form-control" id="exampleInputAddressLine1" placeholder="Enter your address">
                          </div>
                        
                          <div class="form-group address details">
                              <label for="exampleInputCity">City *</label>
                              <input type="text" class="form-control" id="exampleInputCity" placeholder="Enter your City">
                          </div>
                        
                          <div class="form-group address details">
                              <label for="exampleInputZipcode">Zipcode *</label>
                              <input type="number" class="form-control" id="exampleInputZipcode" placeholder="Enter your Zipcode">
                          </div>
                    </div> 
                      
                    <div class="col-sm-6">
                          <div class="form-group address details">
                              <label for="exampleInputAddressLine2">Address Line 2 *</label>
                              <input type="text" class="form-control" id="exampleInputAddressLine2" placeholder="Enter your address">
                          </div>
                        
                          <div class="form-group address details">
                              <label for="exampleInputState">State *</label>
                              <input type="text" class="form-control" id="exampleInputState" placeholder="Enter your State">
                          </div>
                        
                          <div class="form-group address details">
                              <label for="exampleInputCountry">Country *</label>
                              <input type="text" class="form-control" id="exampleInputCountry" placeholder="Enter your Country">
                          </div>
                    </div> 
                      
                    <div class="add-notes-1">
                        <span class="content-university-and-college-information">University and College Information</span>
                    </div>
                      
                    <div class="col-sm-6">
                          <div class="form-group university and college information">
                            <label for="exampleInputUniversity">University</label>
                            <input type="text" class="form-control" id="exampleInputUniversity" placeholder="Enter your university name">
                          </div>
                    </div> 
                      
                    <div class="col-sm-6">
                          <div class="form-group university and college information">
                            <label for="exampleInputCollege">College</label>
                            <input type="text" class="form-control" id="exampleInputCollege" placeholder="Enter your college name">
                          </div>
                    </div>            

                </div>
                
                
                </form>
            </div>  
                
            <div class="col-md-12">
                <button type="button" class="btn">SUBMIT</button>
            </div>
            
        </div>
    </section>
    <!-- Footer -->
    <footer>

        <div class="container-fluid" style="margin: 2%;">
  
            <div class="row">
                <div class="col-md-6" style="margin-left: 5%;">
                    <p>
                        <span>Copyright &copy; Tatvasoft All rights reserved.</span>
                    </p>
                </div>
                <div style="text-align: right; margin-right:5%; ">
                  <a href="#"><i class="fa fa-facebook" ></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-google-plus"></i></a> 
                </div>
            </div>

      </div>

        <!-- Back To Top -->
        <a href="#home" id="back-to-top" class="btn btn-sm btn-yellow btn-back-to-top smooth-scroll col-md-12 hidden-sm hidden-xs" title="home" role="button">
            <i class="fa fa-angle-up"></i>
        </a>

    </footer>
    <!-- Footer Ends -->

        <!-- JQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="js/bootstrap/bootstrap.min.js"></script>

    <script type="text/javascript" src="js/style.js"></script>

</body>
</html>