<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">

    <title>Add Category</title>

    <link rel="stylesheet" type="text/css" href="css/Add%20Type.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">
</head>


<body>

    <!-- Sticky Pages -->
    <header class="site-header">
          <div class="header-wrapper">
            <div class="logo-wrapper">

            <!-- Logo -->
            <a href="#" title="Site Logo" class="navbar-brand">
              <img src="img/dark-top-logo.png" id="logo">
            </a>

            </div>

            <!-- Main Menu bar -->
            <div class="navigation-wrapper">
              <nav class="main-nav">  
                 <ul class="menu-navigation">
                    <li>
                      <a href="../Front/Search%20Page.php">Search Notes</a>
                    </li>
                    <li>
                      <a href="sold-notes.php">Sell Your Notes</a>
                    </li>
                    <li>
                      <a href="../Front/FAQ.php">FAQ's</a>
                    </li>
                    <li>
                      <a href="Contact%20Us.php">Contact Us</a>
                    </li>
                    <li>
                      <button id="logout-button">Logout</button>
                    </li>
                  </ul>     
              </nav>
            </div>

          </div>
    </header> 
    <!-- End Header -->


    <section id="contact-us">
      <div style="position: relative;">
        <img src="img/banner-with-overlay.jpg" class="banner">
        <p class="content-img">Add Type</p>
      </div>
    </section>

    <section id="contact-us-form">
        <div class="container">

            <div class="contact-1">
                <span class="content-top">Add Type</span>
            </div>
              
            <div class="contact-2">
                
                <form class="form-details">

                  <div class="form">
                      
                      <div class="col-sm-6">
                    
                        <div class="form-group">
                          <label for="exampleInputType">Type *</label>
                          <input type="text" class="form-control" id="exampleInputType" placeholder="Enter Type">
                        </div>
                          
                        <div class="form-group comments">
                          <label for="exampleFormControlDescription">Description *</label>
                          <textarea class="form-control" id="exampleFormControlDescription" rows="5" placeholder="Enter your decription"></textarea>
                        </div>

                                                                    
                      </div>
                  </div>

                  
                
                </form>
            </div>  
            
            <div class="col-md-12">
                <button type="submit" class="btn">SUBMIT</button>
            </div>
            
        </div>
    </section>
    <!-- Footer  -->
    <footer>

        <div class="container-fluid" style="margin: 2%;">
  
            <div class="row">
                <div class="col-md-6" style="margin-left: 5%;">
                    <p>
                        <span>Copyright &copy; Tatvasoft All rights reserved.</span>
                    </p>
                </div>
                <div style="text-align: right; margin-right:5%; ">
                  <a href="#"><i class="fa fa-facebook" ></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-google-plus"></i></a> 
                </div>
            </div>

      </div>

        <!-- Back To Top -->
        <a href="#home" id="back-to-top" class="btn btn-sm btn-yellow btn-back-to-top smooth-scroll col-md-12 hidden-sm hidden-xs" title="home" role="button">
            <i class="fa fa-angle-up"></i>
        </a>

    </footer>
    <!-- Footer Ends -->

       
        <!-- JQuery -->
    <script src="js/jquery.min.js"></script>    

    <!-- Bootstrap JS -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/style.js"></script>


</body>
</html>