<?php
include "db.php";

session_start();
if (!isset($_SESSION['userid']))
    header('Location:Login Page.php');

$userid = $_SESSION['userid'];
$sql = mysqli_query($con, "SELECT * FROM users WHERE userid='$userid'");
while ($row = mysqli_fetch_array($sql)) {
    $password = $row['password'];
    $userid = $row['userid'];
}

$newpassword = "";
$cpassword = "";
$oldpassword= "";

if (isset($_POST['submit'])) {
    $oldpassword = $_POST['oldpassword'];
    $newpassword = $_POST['newpassword'];
    $cpassword = $_POST['cpassword'];

    if($newpassword==$cpassword){    
        $upassword = mysqli_query($con, "UPDATE users SET password='$newpassword',modifieddate=NOW(),modifiedby=$userid WHERE userid=$userid");
        echo '<script>alert("Your password has been changed sucessfully..")</script>';
        echo '<script>window.location.replace("logout.php")</script>';
    }else{
        echo '<script>alert("woops! Password does not match...")</script>';
    }
}
?>



<!DOCTYPE html>
<html lang="en">
   <head>
       
       
    <!-- important meta tags in html -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    
    <link rel="stylesheet" href="css/Change%20Password.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.css">
   </head>
    
    <body>
        
       <!-- Login -->
        <div class="login-box">
            <img id="img-1" src="img1/top-logo.png">
            <div class="centerdiv">
                <h1 id="header-1">Change Password</h1>
                <h5 id="text-1">Enter your new password to change your password</h5>
                <form action="" method="post">
                    
                    <div class="form-group">
                        <label for="exampleInputOldPassword1">Old Password*</label>
                        <input type="password" name="oldpassword" class="form-control" id="exampleInputOldPassword1" placeholder="Enter your old password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputNewPassword1">New Password</label>
                        <input type="password"  name="newpassword" class="form-control" id="exampleInputNewPassword1" placeholder="Enter your new Password" required>
                    </div>

                    
                    
                    <div class="form-group">
                        <label for="exampleInputConfirmPassword1">Confirm Password</label>
                        <input type="password"  name="cpassword" class="form-control" id="exampleInputConfirmPassword1" placeholder="Re-Enter your new Password" required>
                    </div>
                 
                <button type="submit" name="submit" class="btn">SUBMIT</button>
                    
                  </form>
            </div>
        </div>

       
    </body>
    
</html>