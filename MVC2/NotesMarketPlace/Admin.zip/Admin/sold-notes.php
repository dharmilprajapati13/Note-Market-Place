<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
  
  <!-- title -->
  <title>Sold notes - Marketplace</title>

  <link rel="stylesheet" type="text/css" href="css/sold-notes.css">
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">
</head>

<body>

  <!-- Sticky Pages -->
  <header class="site-header">
    <div class="header-wrapper">
      <div class="logo-wrapper">

        <!-- Logo -->
        <a href="#" title="Site Logo" class="navbar-brand">
          <img src="images/logo.png" id="logo">
        </a>

      </div>

      <!-- Main Menu bar -->
      <div class="navigation-wrapper">
        <nav class="main-nav">
          <ul class="menu-navigation">
            <li>
              <a href="Search%20Page.php">Search Notes</a>
            </li>
            <li>
              <a href="sold-notes.php">Sell Your Notes</a>
            </li>
            <li>
              <a href="FAQ.php">FAQ's</a>
            </li>
            <li>
              <a href="Contact%20Us.php">Contact Us</a>
            </li>
            <li>
              <a href="#">

                <div class="dropdown">
                  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img src="img/team-1.jpg" class="profile-img">
                  </a>

                  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <a class="dropdown-item" href="My%20Profile.php" style="padding: 5%;border: 1px solid;width: 100%;">My Profile</a>
                    <a class="dropdown-item" href="Download-Notes.php" style="padding: 5%;border: 1px solid;width: 100%;">My Download</a>
                    <a class="dropdown-item" href="sold-notes.php" style="padding: 5%;border: 1px solid;width: 100%;">My Sold
                      Notes</a>
                    <a class="dropdown-item" href="My%20Rejected%20Notes.php" style="padding: 5%;border: 1px solid;width: 100%;">My Rejected
                      Notes</a>
                    <a class="dropdown-item" href="Change%20Password.php" style="padding: 5%;border: 1px solid;width: 100%;">Change
                      Password</a>
                    <a class="dropdown-item" href="logout.php"
                      style="padding: 5%;border: 1px solid;width: 100%; color: #6255a5;">LOGOUT</a>
                  </div>
              </a>
            </li>
            <li>
              <button id="logout-button">Logout</button>
            </li>
          </ul>
        </nav>
      </div>

    </div>
  </header>
  <!-- End Header -->

  <!-- my sold Notes -->
  <section>
    <div class="container top-content">
      <div class="dash">
        <span class="dashboard-content">My Sold Notes</span>
        <div class="right-nav">
          <input type="text" placeholder="Search" class="btn-search fa fa-search" style="height: 4.3%;">
          <button class="btn btn-note">Search</button>
        </div>
      </div>
    </div>
  </section>


  <!-- My sold Tables -->
  <section id="my-sold-notes-table">
    <div class="container">
      <div class="row" id="my-sold-notes-table-margin">
        <table class="table table-bordered table-hover">
          <thead>
            <tr>
              <th scope="col" style="border-right: hidden;">SR NO.</th>
              <th scope="col" style="border-right: hidden;">NOTE TITLE</th>
              <th scope="col" style="border-right: hidden;">CATAGORY</th>
              <th scope="col" style="border-right: hidden;">BUYER</th>
              <th scope="col" style="border-right: hidden;">SELL TYPE</th>
              <th scope="col" style="border-right: hidden;">PRICE</th>
              <th scope="col" style="border-right: hidden;">DOWNLOADED DATE/TIME</th>
              <th scope="col">ACTION</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <th scope="row" style="border-right: hidden;">1</th>
              <td class="text-color" style="border-right: hidden;">Data Science</td>
              <td style="border-right: hidden;">Science</td>
              <td style="border-right: hidden;">testing123@gmail.com</td>
              <td style="border-right: hidden;">Paid</td>
              <td style="border-right: hidden;">$250</td>
              <td style="border-right: hidden;">27 Nov 2020, 11:24:34</td>
              <td class="dropdown">
                <a class="link-margin" href="#"><img src="images/eye.png"></a>
                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false"><img src="images/dots.png"></a>
                <a class="dropdown-item dropdown-menu" aria-labelledby="dropdownMenuLink" href="#"
                  style="text-align: center; font-family: Open Sans; font-size: 15px; font-weight: 400; line-height: normal; text-decoration: none; color: #333333;">Download
                  Note</a>
              </td>
            </tr>

            <tr>
              <th scope="row" style="border-right: hidden;">2</th>
              <td class="text-color" style="border-right: hidden;">Accounts</td>
              <td style="border-right: hidden;">Commerce</td>
              <td style="border-right: hidden;">testing123@gmail.com</td>
              <td style="border-right: hidden;">Free</td>
              <td style="border-right: hidden;">$0</td>
              <td style="border-right: hidden;">27 Nov 2020, 11:24:34</td>
              <td class="dropdown">
                <a class="link-margin" href="#"><img src="images/eye.png"></a>
                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false"><img src="images/dots.png"></a>
                <a class="dropdown-item dropdown-menu" aria-labelledby="dropdownMenuLink" href="#"
                  style="text-align: center; font-family: Open Sans; font-size: 15px; font-weight: 400; line-height: normal; text-decoration: none; color: #333333;">Download
                  Note</a>
              </td>
            </tr>

            <tr>
              <th scope="row" style="border-right: hidden;">3</th>
              <td class="text-color" style="border-right: hidden;">Social Studies</td>
              <td style="border-right: hidden;">Social</td>
              <td style="border-right: hidden;">testing123@gmail.com</td>
              <td style="border-right: hidden;">Free</td>
              <td style="border-right: hidden;">$0</td>
              <td style="border-right: hidden;">27 Nov 2020, 11:24:34</td>
              <td class="dropdown">
                <a class="link-margin" href="#"><img src="images/eye.png"></a>
                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false"><img src="images/dots.png"></a>
                <a class="dropdown-item dropdown-menu" aria-labelledby="dropdownMenuLink" href="#"
                  style="text-align: center; font-family: Open Sans; font-size: 15px; font-weight: 400; line-height: normal; text-decoration: none; color: #333333;">Download
                  Note</a>
              </td>
            </tr>

            <tr>
              <th scope="row" style="border-right: hidden;">4</th>
              <td class="text-color" style="border-right: hidden;">AI</td>
              <td style="border-right: hidden;">IT</td>
              <td style="border-right: hidden;">testing123@gmail.com</td>
              <td style="border-right: hidden;">Paid</td>
              <td style="border-right: hidden;">$158</td>
              <td style="border-right: hidden;">27 Nov 2020, 11:24:34</td>
              <td class="dropdown">
                <a class="link-margin" href="#"><img src="images/eye.png"></a>
                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false"><img src="images/dots.png"></a>
                <a class="dropdown-item dropdown-menu" aria-labelledby="dropdownMenuLink" href="#"
                  style="text-align: center; font-family: Open Sans; font-size: 15px; font-weight: 400; line-height: normal; text-decoration: none; color: #333333;">Download
                  Note</a>
              </td>
            </tr>

            <tr>
              <th scope="row" style="border-right: hidden;">5</th>
              <td class="text-color" style="border-right: hidden;">Lorem ipsum</td>
              <td style="border-right: hidden;">Lorem</td>
              <td style="border-right: hidden;">testing123@gmail.com</td>
              <td style="border-right: hidden;">Free</td>
              <td style="border-right: hidden;">$0</td>
              <td style="border-right: hidden;">27 Nov 2020, 11:24:34</td>
              <td class="dropdown">
                <a class="link-margin" href="#"><img src="images/eye.png"></a>
                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false"><img src="images/dots.png"></a>
                <a class="dropdown-item dropdown-menu" aria-labelledby="dropdownMenuLink" href="#"
                  style="text-align: center; font-family: Open Sans; font-size: 15px; font-weight: 400; line-height: normal; text-decoration: none; color: #333333;">Download
                  Note</a>
              </td>
            </tr>

            <tr>
              <th scope="row" style="border-right: hidden;">6</th>
              <td class="text-color" style="border-right: hidden;">Data Science</td>
              <td style="border-right: hidden;">Science</td>
              <td style="border-right: hidden;">testing123@gmail.com</td>
              <td style="border-right: hidden;">Paid</td>
              <td style="border-right: hidden;">$555</td>
              <td style="border-right: hidden;">27 Nov 2020, 11:24:34</td>
              <td class="dropdown">
                <a class="link-margin" href="#"><img src="images/eye.png"></a>
                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false"><img src="images/dots.png"></a>
                <a class="dropdown-item dropdown-menu" aria-labelledby="dropdownMenuLink" href="#"
                  style="text-align: center; font-family: Open Sans; font-size: 15px; font-weight: 400; line-height: normal; text-decoration: none; color: #333333;">Download
                  Note</a>
              </td>
            </tr>

            <tr>
              <th scope="row" style="border-right: hidden;">7</th>
              <td class="text-color" style="border-right: hidden;">Accounts</td>
              <td style="border-right: hidden;">Commerce</td>
              <td style="border-right: hidden;">testing123@gmail.com</td>
              <td style="border-right: hidden;">Free</td>
              <td style="border-right: hidden;">$0</td>
              <td style="border-right: hidden;">27 Nov 2020, 11:24:34</td>
              <td class="dropdown">
                <a class="link-margin" href="#"><img src="images/eye.png"></a>
                <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false"><img src="images/dots.png"></a>
                <a class="dropdown-item dropdown-menu" aria-labelledby="dropdownMenuLink" href="#"
                  style="text-align: center; font-family: Open Sans; font-size: 15px; font-weight: 400; line-height: normal; text-decoration: none; color: #333333;">Download
                  Note</a>
              </td>
            </tr>
            <!-- </thead> -->
          </tbody>
        </table>
      </div>
    </div>

    <center>
      <div>
        <span id="icon-margin-right"><a href="#"><img src="images/left-arrow.png" width="5" height="10"></a></span>
        <span class="btn btn-primary btn-circle btn-sm">1</span>
        <span class="btn btn-primary btn-circle btn-sm">2</span>
        <span class="btn btn-primary btn-circle btn-sm">3</span>
        <span id="icon-margin-left"><a href="#"><img src="images/right-arrow.png" width="5" height="10"></a></span>
      </div>
    </center>
  </section>
  <br>
  <hr>

  <!-- Footer  -->
  <footer>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6" style="margin-left: 5%;">
          <p>
            Copyright &copy; Tatvasoft All rights reserved.</span>
          </p>
        </div>
        <div style="text-align: right; margin-right:5%; ">
          <span class="btn btn-primary btn-circle btn-sm"><i class="fa fa-facebook"></i></span>
          <span class="btn btn-primary btn-circle btn-sm"><i class="fa fa-twitter"></i></span>
          <span class="btn btn-primary btn-circle btn-sm"><i class="fa fa-google-plus"></i></span>
        </div>
      </div>
    </div>

    <!-- Back To Top -->
    <!-- <a href="#home" id="back-to-top" class="btn btn-sm btn-yellow btn-back-to-top smooth-scroll col-md-12 hidden-sm hidden-xs" title="home" role="button">
            <i class="fa fa-angle-up"></i>
        </a> -->
  </footer>
  <!-- Footer Ends -->

  <!-- JQuery -->
  <script src="js/jquery.min.js"></script>

  <!-- Bootstrap JS -->
  <script src="js/bootstrap/bootstrap.min.js"></script>

  <!-- java script -->
  <script type="text/javascript" src="js/style.js"></script>

</body>

</html>