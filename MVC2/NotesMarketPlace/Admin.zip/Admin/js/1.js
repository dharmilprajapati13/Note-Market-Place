function hideIcon(self) {
    self.style.backgroundImage = 'none';
}