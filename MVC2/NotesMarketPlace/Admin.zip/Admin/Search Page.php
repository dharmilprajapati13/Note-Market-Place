<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">

    <!-- title -->
    <title>search-page</title>

    <link rel="stylesheet" type="text/css" href="css/Search%20Page.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">
</head>

<body>

    <!-- Sticky Pages -->
    <header class="site-header">
          <div class="header-wrapper">
            <div class="logo-wrapper">

            <!-- Logo -->
            <a href="#" title="Site Logo" class="navbar-brand">
              <img src="img2/top-logo.png" id="logo">
            </a>

            </div>

            <!-- Main Menu bar -->
            <div class="navigation-wrapper">
              <nav class="main-nav">  
                 <ul class="menu-navigation">
                    <li>
                      <a href="Search%20Page.php">Search Notes</a>
                    </li>
                    <li>
                      <a href="sold-notes.php">Sell Your Notes</a>
                    </li>
                    <li>
                      <a href="FAQ.php">FAQ's</a>
                    </li>
                    <li>
                      <a href="Contact%20Us.php">Contact Us</a>
                    </li>
                    <li>
                      <button id="login-button">Login</button>
                    </li>
                  </ul>     
              </nav>
            </div>

          </div>
    </header> 

    <section id="search-img">
        <img src="images/Search/banner-with-overlay.jpg" alt="image" class="img-responsive">
        <div id="img-content">
            <h1>Search Notes</h1>
        </div>
    </section>

    <section id="filternotes">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="note-title">
                       <h4>Search and Filter notes</h4> 
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <div id="search-lines">
                        <div id="line-1">
                            <input type="text" class="form-control form-control-lg" id="notename" placeholder="Search notes here...">
                        </div> 
                        
                        <div id="line-2" class="form-inline">
                            <div class="form-group">
                                <select class="form-control form-control-lg" id="type">
                                  <option value="" disabled selected>Select Type</option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control form-control-lg" id="category">
                                  <option value="" disabled selected>Select Category</option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control form-control-lg" id="university">
                                  <option value="" disabled selected>Select University</option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control form-control-lg" id="course">
                                  <option value="" disabled selected>Select Course</option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control form-control-lg" id="country">
                                  <option value="" disabled selected>Select Country</option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control form-control-lg" id="rating">
                                  <option value="" disabled selected>Select Rating</option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                </select>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="notes">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="note-title">
                       <h4>Total 18 notes</h4> 
                    </div>
                </div>
            </div>
            
            <!-- line 1 -->
            <div class="row">
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/1.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>Computer Operating System - Final Exam Book With Paper Solution</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/2.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>Computer Science</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/3.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>Basic Computer Engineering Tech India Publication Series</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- line 2 -->
            <div class="row">
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/4.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>Computer Science Illuminted - Seventh Edition</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/5.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>The Principles of Computer Hardware - Oxford</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/6.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>The Computer Book</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- line 3 -->
            <div class="row">
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/1.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>Computer Operating System - Final Exam Book With Paper Solution</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/2.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>Computer Science</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="notebox">
                        <div class="note-img">
                            <img src="images/Search/3.jpg" alt="note" class="img-responsive">
                        </div>
                        <div class="note-content">
                            <h5>Basic Computer Engineering Tech India Publication Series</h5>
                            <ul class="note-content-inner">
                                <li><i class="fa fa-university"></i><span>University of California, US</span></li>
                                <li><i class="fa fa-book"></i><span>204 Pages</span></li>
                                <li><i class="fa fa-calendar"></i><span>Thu, Dec 24 2020</span></li>
                                <li><i class="fa fa-flag"></i><span id="flag">5 Users marked this note as inappropiate</span></li>
                            </ul>
                            <div class="review-stars">
                                <div class="star-rating">
                                        <label class="star star-1"></label>
                                        <label class="star star-2"></label>
                                        <label class="star star-3"></label>
                                        <label class="star star-4"></label>
                                        <label class="star star-5"></label>
                                        <div class="star-review">
                                            <span>100 reviews</span>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="pagination">
        <nav aria-label="Page navigation">
          <ul class="pagination justify-content-center">
            <li class="page-item">
              <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true"><i class="fa fa-angle-left" aria-hidden="true"></i></span>
              </a>
            </li>
            <li class="page-item"><a class="page-link active" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">4</a></li>
            <li class="page-item"><a class="page-link" href="#">5</a></li>
            <li class="page-item">
              <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
              </a>
            </li>
          </ul>
        </nav>
    </section>

    <!-- Footer  -->
    <footer>

        <div class="container-fluid">
  
            <div class="row">
                <div class="col-md-6" style="margin-left: 5%;">
                    <p>
                        Copyright &copy; Tatvasoft All rights reserved.
                    </p>
                </div>
                <div style="text-align: right; margin-right:5%; ">
                  <a href="#"><i class="fa fa-facebook" ></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-google-plus"></i></a> 
                </div>
            </div>

      </div>

        <!-- Back To Top -->
        <a href="#home" id="back-to-top" class="btn btn-sm btn-yellow btn-back-to-top smooth-scroll col-md-12 hidden-sm hidden-xs" title="home" role="button">
            <i class="fa fa-angle-up"></i>
        </a>

    </footer>
    <!-- Footer Ends -->

        <!-- JQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="js/bootstrap/bootstrap.min.js"></script>

    <script type="text/javascript" src="js/style.js"></script>

</body>
</html>