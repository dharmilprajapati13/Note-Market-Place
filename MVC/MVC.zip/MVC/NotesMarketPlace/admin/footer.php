  <!--footer-->
  <footer>
      <div id="footer">
          <hr>
          <div class="container-fluid">
              <div class="row">
                  <div class="col-md-1 col-sm-0 col-0">
                  </div>
                  <div class="col-md-5 col-sm-4 col-12">
                      <h4 id="footer-ver-info" class="dark-font-14">Version : 1.1.24</h4>
                  </div>
                  <div class="col-md-6 col-sm-8 col-12">
                      <h3>Copyright &#169; <a href="https://www.tatvasoft.com/"
                              title="TatvaSoft-click here for more info">TatvaSoft </a> All rights reserved.
                      </h3>
                  </div>
              </div>
          </div>
      </div>
  </footer>
  <!--footer end-->