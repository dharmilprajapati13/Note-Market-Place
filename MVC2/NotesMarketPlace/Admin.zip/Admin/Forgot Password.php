<?php
include "db.php";
session_start();


use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

$mailsent = false;
$acc_exist = true;
if (isset($_POST['submit'])) {
    $emailid = $_POST['emailid'];
    $sql = "SELECT * FROM users WHERE emailid='$emailid'";
    $result = mysqli_query($con, $sql);
    $emailid_count = mysqli_num_rows($result);

    if ($emailid_count == 1) {

        function password_generate($chars) {
                $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
                return substr(str_shuffle($data), 0, $chars);
                }
            $password = password_generate(7);
        
        
        $sql = "UPDATE users SET password='$password' WHERE emailid='$emailid'";
        mysqli_query($con, $sql);

        require 'PHPMailer/Exception.php';
        require 'PHPMailer/PHPMailer.php';
        require 'PHPMailer/SMTP.php';

        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $config_email = 'dharmilprajapati45@gmail.com';
            $mail->Username = $config_email;
            $mail->Password = '45Dharmil45';

            $mail->setFrom('dharmilprajapati45@gmail.com', 'NotesMarketPlace');

            $mail->addAddress($emailid, 'Dear user');
            $mail->addReplyTo('dharmilprajapati45@gmail.com', 'NotesmarktPlace');

           $mail->IsHTML(true);
            $mail->Subject = "Forgot password";
            $mail->Body = " Hello,<br>
            We have generated a new password for you<br>
            Password: $password <br>
            Email: $emailid <br>
            Regards,<br>
            Notes Marketplace<br>";
            $mail->AltBody = '';

            $mail->send();
            $mailsent = true;
        } catch (Exception $e) {
            echo "error in sending emailid...Error: {$mail->ErrorInfo}";
        }
    } else if ($emailid_count == 0) {
        $acc_exist = false;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
   <head>
       
       
    <!-- important meta tags in html -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Title -->
    <link rel="stylesheet" href="css/Forget%20Password.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.css">
   </head>
    
    <body>
        
       <!-- Login -->
        <div class="login-box">
            <img id="img-1" src="img1/top-logo.png">
            <div class="centerdiv">
                <h1 id="header-1">Forgot Password?</h1>
                <h5 id="text-1">Enter your email to reset your password</h5>
                <form action="" method="post">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" name="emailid" class="form-control" id="exampleInputEmail1" placeholder="Enter email address">
                    <?php
                        if (!$acc_exist) {
                            echo "Enter a Valid emailid";
                        }
                    ?>

                  </div>
                  
                    <button type="submit" name="submit" class="btn">SUBMIT</button>
                    
                    <div id="account-error">
                        <?php
                            if (!$acc_exist)
                                echo "<h3>There is not any account associated with this emailid <span>" . $emailid . "</span></h3>";
                            else if ($mailsent)
                                echo "<h3>Your password has been changed successfully.New generated password is sent on your registered emailid <span> " . $emailid . "</span></h3>";
                        ?>
                    </div>

                  </form>
            </div>
        </div>

       
    </body>
    
</html>