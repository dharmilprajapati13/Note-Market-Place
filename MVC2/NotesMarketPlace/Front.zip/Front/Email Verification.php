<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0 ,user-scalable=no">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.css">
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/Email%20Verification.css">
    <title>Email Verify</title>
</head>

<body>

    <section id="email-verify">

        <img id="img-1" src="img1/logo.png">
        <h1 id="header-1">Email Verification</h1>
        <h1 id="header-1">Thanks For Signing Up!</h1>
        <h1 id="header-1">Please verify the email address via<br>
        clicking on the link we sent you via email.</h1>
       <!-- <button type="submit" class="btn">VERIFY EMAIL ADDRESS</button> -->
    </section>
    


    <!-- script-->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <script src="js/script.js"></script>

</body>

</html>
