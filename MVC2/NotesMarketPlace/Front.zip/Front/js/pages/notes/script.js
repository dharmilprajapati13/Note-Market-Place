$(function () {
    $("#btnClosePopup").click(function () {
        $("#Modal").modal("hide");
    });
});
