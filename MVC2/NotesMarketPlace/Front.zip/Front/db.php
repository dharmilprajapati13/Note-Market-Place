<?php
$server = "localhost";
$user = "root";
$pass = "";
$database = "notes_marketplace";

$con = mysqli_connect($server, $user, $pass, $database);

if (!$con) {
    die('Connect Error: ' . mysqli_connect_error());
}
