<?php

use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;


$name_pattern = '/^[a-zA-Z ]*$/';
$email_pattern = "/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/";


$mail_sent = false;
$name_check = true;
$subject_check = true;
$des_check = true;
$mail_check = true;

if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $comment = $_POST['comment'];

    preg_match($name_pattern, $name, $name_match);
    if (!$name_match[0]) {
        $name_check = false;
    }

    preg_match($name_pattern, $subject, $subject_match);
    if (!$subject_match[0]) {
        $subject_check = false;
    }

    preg_match($name_pattern, $comment, $comment_match);
    if (!$comment_match[0]) {
        $des_check = false;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mail_check = false;
    }

    if ($email != "" && $name_check && $subject_check && $des_check && $mail_check) {

        require 'PHPMailer/Exception.php';
        require 'PHPMailer/PHPMailer.php';
        require 'PHPMailer/SMTP.php';

        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $config_email = 'dharmilprajapati45@gmail.com';
            $mail->Username = $config_email;
            $mail->Password = '45Dharmil45';

            // Sender and recipient settings
            $mail->setFrom($email, $name);

            $mail->addAddress('dharmilprajapati45@gmail.com', 'NotesMarketPlace');
            $mail->addReplyTo($email, $name);

            $mail->IsHTML(true);
            $mail->Subject = "$subject";
            $mail->Body = "Sender-Name: <b>$name</b><br><br>Sender-Email: <b>$email</b><br><br>
                           Comment: <b>$comment</b>";
            $mail->AltBody = '';
            $mail->send();
            $mail_sent = true;
        } catch (Exception $e) {
            echo "error to sending email....Error: {$mail->ErrorInfo}";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">

    <title>Contact Us - Marketplace</title>

    <link rel="stylesheet" type="text/css" href="css/Contact%20Us.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">
</head>

<body>

    <!-- Sticky Pages -->
    <header class="site-header">
          <div class="header-wrapper">
            <div class="logo-wrapper">

            <!-- Logo -->
            <a href="#" title="Site Logo" class="navbar-brand">
              <img src="img/dark-top-logo.png" id="logo">
            </a>

            </div>

            <!-- Main Menu bar -->
            <div class="navigation-wrapper">
              <nav class="main-nav">  
                 <ul class="menu-navigation">
                    <li>
                      <a href="Search%20Page.php">Search Notes</a>
                    </li>
                    <li>
                      <a href="sold-notes.php">Sell Your Notes</a>
                    </li>
                    <li>
                      <a href="FAQ.php">FAQ's</a>
                    </li>
                    <li>
                      <a href="Contact%20Us.php">Contact Us</a>
                    </li>
                    <li>
                      <button id="logout-button">Logout</button>
                      
                    </li>
                  </ul>     
              </nav>
            </div>

          </div>
    </header> 
    <!-- End Header -->


    <section id="contact-us">
      <div style="position: relative;">
        <img src="img/banner-with-overlay.jpg" class="banner">
        <p class="content-img">Contact Us</p>
      </div>
    </section>

    <section id="contact-us-form">
        <div class="container">

            <div class="contact-1">
                <span class="content-top">Get In Touch</span>
                <p>Let us know how to get back to you</p>

            </div>
             
              
            <div class="contact-2">
                
                <form class="form-details" action="" method="post">

                  <div class="form">
                      
                      <div class="col-sm-6">
                    
                        <div class="form-group">
                          <label for="exampleInputName1">Name *</label>
                          <input type="text" name="name" class="form-control" id="exampleInputName1" placeholder="Enter your full name">
                                    
                        </div>

                        <div class="form-group">
                          <label for="exampleInputEmail1">Email address *</label>
                          <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your email address">           
                        </div>
                      
                        <div class="form-group">
                          <label for="exampleInputSubject1">Subject *</label>
                          <input type="text" name="subject" class="form-control" id="exampleInputSubject1" placeholder="Enter your subject">
                        </div>
                      
                      </div>

                      <div class="col-sm-6">
                          <div class="form-group comments">
                            <label for="exampleFormControlComments1">Comments / Questions *</label>
                            <textarea class="form-control"  name="comment" id="exampleFormControlComments1" rows="8" placeholder="Comments..."></textarea>
                            
                          </div>
                      </div>

                  </div>
                  <div class="col-md-12">
                <button type="submit" name="submit" class="btn">SUBMIT</button>
                </div>
 
                </form>
            </div>  
            
            
            
        </div>
    </section>
    <!-- Footer  -->
    <footer>

        <div class="container-fluid" style="margin: 2%;">
  
            <div class="row">
                <div class="col-md-6" style="margin-left: 5%;">
                    <p>
                        Copyright &copy; Tatvasoft All rights reserved.</span>
                    </p>
                </div>
                <div style="text-align: right; margin-right:5%; ">
                  <a href="#"><i class="fa fa-facebook" ></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-google-plus"></i></a> 
                </div>
            </div>

      </div>

        <!-- Back To Top -->
        <a href="#home" id="back-to-top" class="btn btn-sm btn-yellow btn-back-to-top smooth-scroll col-md-12 hidden-sm hidden-xs" title="home" role="button">
            <i class="fa fa-angle-up"></i>
        </a>

    </footer>
    <!-- Footer Ends -->

        <!-- JQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="js/bootstrap/bootstrap.min.js"></script>

    <script type="text/javascript" src="js/style.js"></script>

</body>
</html>