<?php
include "db.php";

session_start();
   
$sellerid=$_SESSION['userid'];

if(isset($_POST['publish'])){
    $status="1";
    $date=date('dd-mm-yy');
    $title=$_POST['title'];
    $category=$_POST['category'];
    $displaypicture=basename($_FILES['displaypicture']['name']);
    $displaypicture_temp=$_FILES['displaypicture']['tmp_name'];
    $uploadnotes=basename($_FILES['uploadnotes']['name']);
    $uploadnotes_temp=$_FILES['uploadnotes']['tmp_name'];
    $type=$_POST['type'];
    $noofpages=$_POST['noofpages'];
    $description=$_POST['description'];
    $country=$_POST['country'];
    $iname=$_POST['iname'];
    $coursename=$_POST['coursename'];
    $coursecode=$_POST['coursecode'];
    $proffesor=$_POST['proffesor'];
    $coursecode=$_POST['coursecode'];
    $sellfor=$_POST['sellfor'];
    $sellprice=$_POST['sellprice'];
    $notepre=basename($_FILES['notepre']['name']);
    $notepre_temp=$_FILES['notepre']['tmp_name'];
      
    move_uploaded_file($displaypicture_temp,'Members/$displaypicture');
    move_uploaded_file($uploadnotes_temp,'Members/$uploadnotes');
    move_uploaded_file($notepre_temp,'Members/$notepre');
     
    $sql1="SELECT * from notecategories WHERE name='$category'";
    $result1=mysqli_query($con,$sql1);
    
    if($row = mysqli_fetch_assoc($result1)){
        $categoryid=$row['categoryid'];
     
    $sql="INSERT into sellernotes (sellerid,status,actionedby,admin_remarks,publisheddate,title,category,displaypic,notetype,	page_no,description,university_name,country,course,course_code,proffesor,ispaid,selling_price,notespreview) ";
$sql.="VALUES ('$sellerid','$status','wow',now(),'$date','$title','$categoryid','$displaypicture','$type','$noofpages','$description','$iname','$country','$coursename','$coursecode','$proffesor','$sellfor','$sellprice','$notepre')";

     $result = mysqli_query($con,$sql);
if(!$result){
    echo "Error".mysqli_error($con);
    }
     
 }
 }



else if(isset($_POST['save'])){
    $status="0";
    $date=date('dd-mm-yy');
    $title=$_POST['title'];
    $category=$_POST['category'];
    $displaypicture=basename($_FILES['displaypicture']['name']);
    $displaypicture_temp=$_FILES['displaypicture']['tmp_name'];
    $uploadnotes=basename($_FILES['uploadnotes']['name']);
    $uploadnotes_temp=$_FILES['uploadnotes']['tmp_name'];
    $type=$_POST['type'];
    $noofpages=$_POST['noofpages'];
    $description=$_POST['description'];
    $country=$_POST['country'];
    $iname=$_POST['iname'];
    $coursename=$_POST['coursename'];
    $coursecode=$_POST['coursecode'];
    $proffesor=$_POST['proffesor'];
    $coursecode=$_POST['coursecode'];
    $sellfor=$_POST['sellfor'];
    $sellprice=$_POST['sellprice'];
    $notepre=basename($_FILES['notepre']['name']);
    $notepre_temp=$_FILES['notepre']['tmp_name']; 
    
     $sql1="SELECT * from notecategories WHERE name='$category'";
    $result1=mysqli_query($con,$sql1);
    
    if($row = mysqli_fetch_assoc($result1)){
        $categoryid=$row['categoryid'];
     
    $sql="INSERT into sellernotes (sellerid,status,actionedby,admin_remarks,publisheddate,title,category,displaypic,notetype,	page_no,description,university_name,country,course,course_code,proffesor,ispaid,selling_price,notespreview) ";
$sql.="VALUES ('$sellerid','$status','wow',now(),'$date','$title','$categoryid','$displaypicture','$type','$noofpages','$description','$iname','$country','$coursename','$coursecode','$proffesor','$sellfor','$sellprice','$notepre')";

     $result = mysqli_query($con,$sql);
if(!$result){
    echo "Error".mysqli_error($con);
    }
     
 }    
}


?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">

    <title>Add Notes</title>

    <link rel="stylesheet" type="text/css" href="css/Add%20Notes.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">
</head>

<body>

    <!-- Sticky Pages -->
    <header class="site-header">
          <div class="header-wrapper">
            <div class="logo-wrapper">

            <!-- Logo -->
            <a href="#" title="Site Logo" class="navbar-brand">
              <img src="img/dark-top-logo.png" id="logo">
            </a>

            </div>

            <!-- Main Menu bar -->
            <div class="navigation-wrapper">
              <nav class="main-nav">  
                 <ul class="menu-navigation">
                    <li>
                      <a href="Search%20Page.php">Search Notes</a>
                    </li>
                    <li>
                      <a href="sold-notes.php">Sell Your Notes</a>
                    </li>
                    <li>
                      <a href="FAQ.php">FAQ's</a>
                    </li>
                    <li>
                      <a href="Contact%20Us.php">Contact Us</a>
                    </li>
                    <li>
                      <button id="logout-button">Logout</button>
                    </li>
                  </ul>     
              </nav>
            </div>

          </div>
    </header> 
    <!-- End Header -->

    <!-- Add Notes Section-->
    <section id="add-notes">
      <div style="position: relative;">
        <img src="img/banner-with-overlay.jpg" class="banner">
        <p class="content-img">Add Notes</p>
      </div>
    </section>

    <section id="add-notes-form">
        <div class="container">

            <div class="add-notes-1">
                <span class="content-top">Basic Note Details</span>
            </div>
              
            <div class="contact-2">
                
                <form class="form-details" action="" method="post" enctype="multipart/form-data">

                  <div class="form">
                      
                      <div class="col-sm-6">
                    
                        <div class="form-group">
                          <label for="exampleInputTitle">Title *</label>
                          <input type="text" class="form-control" id="exampleInputTitle"  name="title" placeholder="Enter your notes Title">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputDisplayPicture">Display Picture </label>
                         

                          <input type="file" class="form-control" id="exampleInputDisplayPicture" name="displaypicture" placeholder="Upload a Picture">
                        </div>
                      
                        <div class="form-group">
                          <label for="exampleInputType">Type </label>
                          <select class="form-control" id="exampleInputType" name="type">
                            <option value="" disabled selected>Select your Category</option>
                            <option value="Class Notes">Class Notes</option>
                            <option value="Homework Notes">Homework Notes</option>
                            <option value="Lecture Notes">Lecture Notes</option>
                            <option value="Exam Notes">Exam Notes</option>
                            <option value="Semester Notes">Semester Notes</option>
                            </select>
                        </div>
                      
                      </div>

                      <div class="col-sm-6">
                          <div class="form-group comments">
                            <label for="exampleInputCategory">Category *</label>
                            <select class="form-control" id="exampleInputCategory" placeholder="Select your Category" name="category">
                            <option value="" disabled selected>Select your Category</option>
                            <option value="Class Notes">Class Notes</option>
                            <option value="Homework Notes">Homework Notes</option>
                            <option value="Lecture Notes">Lecture Notes</option>
                            <option value="Exam Notes">Exam Notes</option>
                            <option value="Semester Notes">Semester Notes</option>
                            </select>
                          </div>
                          
                          <div class="form-group comments">
                            <label for="exampleInputUploadNotes">Upload Notes *</label>
                            <input type="file" class="form-control" id="exampleInputUploadNotes" placeholder="Upload your notes" name="uploadnotes">
                          </div>
                          
                          <div class="form-group comments">
                            <label for="exampleInputNumberOfPages">Number of Pages *</label>
                            <input type="text" class="form-control" id="exampleInputNumberOfPages" placeholder="Enter number of note pages" name="noofpages">
                          </div>
                      </div>
                      
                      <div class="col-sm-12">
                        <div class="form-description">
                            <label for="exampleInputDescription">Description *</label>
                            <textarea class="form-control" id="exampleFormControlDescription" rows="6" placeholder="Enter your description" name="description"></textarea>
                        </div>
                      </div>
                
                    <div class="add-notes-1">
                        <span class="content-institution-information">Institution Information</span>
                    </div>
                      
                    <div class="col-sm-6">
                          <div class="form-group institute information">
                            <label for="exampleInputCountry">Country</label>
                            <select class="form-control" id="exampleInputCountry" placeholder="Select your Category" name="country" size="1">
                            <option value="" disabled selected>Select your Country</option>
                            <option value="India">India</option>
                            <option value="USA">USA</option>
                            <option value="UK">UK</option>
                            <option value="Canada">Canada</option>
                            <option value="Germeny">Germeny</option>
                            </select>
                          </div>
                    </div> 
                    <div class="col-sm-6">
                          <div class="form-group institute information">
                            <label for="exampleInputInstituteName">Institite Name</label>
                            <input type="text" class="form-control" id="exampleInputInstituteName" placeholder="Enter your institute name" name="iname">
                          </div>      
                    </div>
                      
                    <div class="add-notes-1">
                        <span class="content-course-details">Course Details</span>
                    </div>
                      
                    <div class="col-sm-6">
                          <div class="form-group course details">
                            <label for="exampleInputCourseName">Course Name</label>
                            <input type="text" class="form-control" id="exampleInputCourseName" placeholder="Enter your course name" name="coursename">
                          </div>
                        
                          <div class="form-group course details">
                            <label for="exampleInputProfessorLecturer">Professor / Lecturer</label>
                            <input type="text" class="form-control" id="exampleInputProfessorLecturer" placeholder="Select yourprofessor name" name="proffesor" size="1">
                          </div>
                    </div> 
                    <div class="col-sm-6">
                          <div class="form-group course details">
                            <label for="exampleInputCourseCode">Course Code</label>
                            <input type="text" class="form-control" id="exampleInputCourseCode" placeholder="Enter your course code" name="coursecode">
                        </div>
                        <div class="form-group course details">
                            <label for="exampleInputCourseCode">Course Code</label>
                            <input type="text" class="form-control" id="exampleInputCourseCode" placeholder="Enter your course code"     >
                        </div>
                        
                    </div>
                   
                    <div class="add-notes-1">
                        <span class="content-selling-information">Selling Information</span>
                    </div>
                      
                    <div class="col-sm-6">
                          <div class="form-group selling information">
                              <label for="exampleInputSellFor">Sell For *</label><br>
                                <input type="radio" id="sellForFree" name="sellfor" value="Free">
                                <label for="male">Free</label>
                                <input type="radio" id="sellForPaid" name="sellfor" value="Paid">
                                <label for="male">Paid</label><br>
                          </div>
                        
                          <div class="form-group selling information">
                            <label for="exampleInputSellPrice">Sell Price *</label>
                            <input type="text" class="form-control" id="exampleInputSellPrice" placeholder="Enter your price" name="sellprice">
                          </div>
                    </div> 
                    <div class="col-sm-6">
                          <div class="form-group selling information">
                            <label for="exampleInputNotePreview">Note Preview</label>
                            <input type="file" class="form-control" id="exampleInputNotePreview" placeholder="Upload a file" name="notepre">
                          </div>      
                    </div>
                    
                    

                </div>
                <div class="col-md-12">
                <button type="submit" class="btn" name="save">save</button>
                <button type="submit" class="btn" name="publish">PUBLISH</button>
            </div>

                
                </form>
            </div>  
                
                        
        </div>
    </section>
    <!-- Footer  -->
    <footer>

        <div class="container-fluid" style="margin: 2%;">
  
            <div class="row">
                <div class="col-md-6" style="margin-left: 5%;">
                    <p>
                        <span>Copyright &copy; Tatvasoft All rights reserved.</span>
                    </p>
                </div>
                <div style="text-align: right; margin-right:5%; ">
                  <a href="#"><i class="fa fa-facebook" ></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-google-plus"></i></a> 
                </div>
            </div>

      </div>

        <!-- Back To Top -->
        <a href="#home" id="back-to-top" class="btn btn-sm btn-yellow btn-back-to-top smooth-scroll col-md-12 hidden-sm hidden-xs" title="home" role="button">
            <i class="fa fa-angle-up"></i>
        </a>

    </footer>
    <!-- Footer Ends -->

        <!-- JQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="js/bootstrap/bootstrap.min.js"></script>

    <script type="text/javascript" src="js/style.js"></script>

</body>
</html>