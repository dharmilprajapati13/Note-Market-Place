<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">

    <title>Dashboard - Marketplace</title>

    <link rel="stylesheet" type="text/css" href="css/Dashboard.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">
</head>

<body>

    <!-- Sticky Pages -->
    <header class="site-header">
          <div class="header-wrapper">
            <div class="logo-wrapper">

            <!-- Logo -->
            <a href="#" title="Site Logo" class="navbar-brand">
              <img src="img/dark-top-logo.png" id="logo">
            </a>

            </div>

            <!-- Main Menu bar -->
            <div class="navigation-wrapper">
              <nav class="main-nav">  
                 <ul class="menu-navigation">
                    <li>
                      <a href="Search%20Page.php">Search Notes</a>
                    </li>
                    <li>
                      <a href="sold-notes.php">Sell Your Notes</a>
                    </li>
                    <li>
                      <a href="FAQ.php">FAQ's</a>
                    </li>
                    <li>
                      <a href="Contact%20Us.php">Contact Us</a>
                    </li>
                    <li>
                      <a href="#">

                        <div class="dropdown">
                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <img src="img/team-1.jpg" class="profile-img">
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                          <a class="dropdown-item" href="My%20Profile.php" style="padding: 5%;border: 1px solid;width: 100%;">My Profile</a>
                          <a class="dropdown-item" href="Download-Notes.php" style="padding: 5%;border: 1px solid;width: 100%;">My Download</a>
                          <a class="dropdown-item" href="sold-notes.php" style="padding: 5%;border: 1px solid;width: 100%;">My Sold Notes</a>
                          <a class="dropdown-item" href="My%20Rejected%20Notes.php" style="padding: 5%;border: 1px solid;width: 100%;">My Rejected Notes</a>
                          <a class="dropdown-item" href="Change%20Password.php" style="padding: 5%;border: 1px solid;width: 100%;">Change Password</a>
                          <a class="dropdown-item" href="logout.php" style="padding: 5%;border: 1px solid;width: 100%; color: #6255a5;">LOGOUT</a>
                        </div>
                        </a>
                    </li>
                    <li>
                      <button id="logout-button">Logout</button>
                    </li>
                  </ul>     
              </nav>
            </div>

          </div>
    </header> 
    <!-- End Header -->

    <!-- Dashboard - Brief-->
    <section>
        <div class="container top-content">
          <div class="dash">
            <span class="dashboard-content">Dashboard</span>
            <button class="btn btn-note right-nav" onclick="document.location.href='Add Notes.php'">ADD NOTE</button>
            
          </div>
        </div>
    </section>
    
    <section id="dashboard-brief">
        <div class="container">
            
            <div class="row" style="margin-left: 0.7%;">
                
                <table class="table table-bordered col-md-6" style="width: 50%;">
                  
                  <thead>
                    <tr>
                      <th scope="col" style="width:2%;padding: 2.5%;">
                        <center>
                        <img class="earning-img" src="img/dashboard-earning.png">
                        <p class="content">My Earning</p>
                        </center>
                      </th>
                      <th scope="col" style="width:10%">
                        <div class="row">
                            <div class="col-md-6">
                              <center>
                                <p class="content">100</p>
                                <p>Number of Notes Sold</p>
                              </center>
                            </div>
                            <div class="col-md-6">
                              <center>
                                <p class="content">$10,00,000</p>
                                <p>Money Earned</p>
                              </center>
                            </div>
                        </div>
                      </th>
                    </tr>
                  </thead>

              </table>

              <table class="table table-bordered col-md-6" style="width: 15%; margin-left: 1%;">
                  <thead>
                    <tr>
                      <th scope="col" style="width: 2%; padding: 8.5%;">
                          <div>
                            <center>
                            <p class="content">38</p>
                            <p>My Downloads</p>
                            </center>
                          </div>
                      </th>
                    </tr>
                  </thead>
              </table>

              <table class="table table-bordered col-md-6" style="width: 15%; margin-left: 1%;">
                  <thead>
                    <tr>
                      <th scope="col" style="width: 2%; padding: 8.5%;">
                          <div>
                            <center>
                            <p class="content">38</p>
                            <p>My Downloads</p>
                            </center>
                          </div>
                      </th>
                    </tr>
                  </thead>
              </table>

              <table class="table table-bordered col-md-6" style="width: 15%; margin-left: 1%;">
                  <thead>
                    <tr>
                      <th scope="col" style="width: 2%; padding: 8.5%;">
                          <div>
                            <center>
                            <p class="content">38</p>
                            <p>My Downloads</p>
                            </center>
                          </div>
                      </th>
                    </tr>
                  </thead>
              </table>

          </div>

        </div>
        
    </section>


    <!-- In Progress Notes -->
    <section>
        <div class="container">
          <div class="dash">
            <span class="dashboard-content">In Progress Notes</span>
            <div class="right-nav">
                <input type="text" placeholder="Search.." class="btn-search fa fa-search" style="height: 4.3%;">
                <button class="btn btn-note">Search</button>
            </div>
          </div>
        </div>
    </section>


    <!-- In Progress Tables -->
    <section id="in-progress-table">
        <div class="container">
            <div class="row" style="margin: 0.7%">
                <table class="table table-bordered">
                    
                    <thead>
                      
                      <tr>
                        <th style="padding: 1.2%">ADDED DATE</th>
                        <th style="padding: 1.2%">TITLE</th>
                        <th style="padding: 1.2%">CATEGORY</th>
                        <th style="padding: 1.2%">STATUS</th>
                        <th style="padding: 1.2%">ACTIONS</th>
                      </tr>

                      <tr>
                        <td>09-10-2020</td>
                        <td>Data Science</td>
                        <td>Science</td>
                        <td>Draft</td>
                        <td>
                          <img src="img/edit.png">
                          <img src="img/eye.png">
                        </td>
                      </tr>

                      <tr>
                        <td>10-10-2020</td>
                        <td>Accounts</td>
                        <td>Commerce</td>
                        <td>In Review</td>
                        <td>
                          <img src="img/edit.png">
                          <img src="img/eye.png">
                        </td>
                      </tr>

                      <tr>
                        <td>11-10-2020</td>
                        <td>Social Stuides</td>
                        <td>Social</td>
                        <td>Submitted</td>
                        <td>
                          <img src="img/edit.png">
                          <img src="img/eye.png">
                        </td>
                      </tr>

                      <tr>
                        <td>12-10-2020</td>
                        <td>AI</td>
                        <td>IT</td>
                        <td>Submitted</td>
                        <td>
                          <img src="img/edit.png">
                          <img src="img/eye.png">
                        </td>
                      </tr>

                    </thead>

                </table>
            </div>
        </div>

        <center>
        <div>
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="round-btn">1</span>
            <span class="round-btn">2</span>
            <span class="round-btn">3</span>
            <span class="round-btn">4</span>
            <span class="round-btn">5</span>
            <span class="glyphicon glyphicon-chevron-right"></span>  
        </div>
        </center>
        

    </section>


<!-- Published Notes -->
    <section>
        <div class="container">
          <div class="dash">
            <span class="dashboard-content">Published Notes</span>
            <div class="right-nav">
                <input type="text" placeholder="Search.." class="btn-search fa fa-search" style="height: 4.3%;">
                <button class="btn btn-note">Search</button>
            </div>
          </div>
        </div>
    </section>

<!-- Published Tables -->
    <section id="in-progress-table">
        <div class="container">
            <div class="row" style="margin: 0.7%">
                <table class="table table-bordered">
                    
                    <thead>
                      
                      <tr>
                        <th style="padding: 1.2%">ADDED DATE</th>
                        <th style="padding: 1.2%">TITLE</th>
                        <th style="padding: 1.2%">CATEGORY</th>
                        <th style="padding: 1.2%">SELL TYPE</th>
                        <th style="padding: 1.2%">PRICE</th>
                        <th style="padding: 1.2%">ACTIONS</th>
                      </tr>

                      <tr>
                        <td>09-10-2020</td>
                        <td>Data Science</td>
                        <td>Science</td>
                        <td>Paid</td>
                        <td>$575</td>
                        <td>
                          <img src="img/eye.png">
                        </td>
                      </tr>

                      <tr>
                        <td>10-10-2020</td>
                        <td>Accounts</td>
                        <td>Commerce</td>
                        <td>Free</td>
                        <td>$0</td>
                        <td>
                          <img src="img/eye.png">
                        </td>
                      </tr>

                      <tr>
                        <td>11-10-2020</td>
                        <td>Social Studies</td>
                        <td>Social</td>
                        <td>Free</td>
                        <td>$0</td>
                        <td>
                          <img src="img/eye.png">
                        </td>
                      </tr>

                      <tr>
                        <td>12-10-2020</td>
                        <td>AI</td>
                        <td>IT</td>
                        <td>Paid</td>
                        <td>$3542</td>
                        <td>
                          <img src="img/eye.png">
                        </td>
                      </tr>

                    </thead>

                </table>
            </div>
        </div>

        <center>
        <div>
           <span class="glyphicon glyphicon-menu-left"></span>
            <span class="round-btn">1</span>
            <span class="round-btn">2</span>
            <span class="round-btn">3</span>
            <span class="round-btn">4</span>
            <span class="round-btn">5</span>
            <span class="glyphicon glyphicon-chevron-right"></span>  
        </div>
        </center>

    </section>



    <!-- Footer  -->
    <footer>

        <div class="container-fluid">
  
            <div class="row">
                <div class="col-md-6" style="margin-left: 5%;">
                    <p>
                        Copyright &copy; Tatvasoft All rights reserved.
                    </p>
                </div>
                <div style="text-align: right; margin-right:5%; ">
                  <a href="#"><i class="fa fa-facebook" ></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-google-plus"></i></a> 
                </div>
            </div>

      </div>

        <!-- Back To Top -->
        <a href="#home" id="back-to-top" class="btn btn-sm btn-yellow btn-back-to-top smooth-scroll col-md-12 hidden-sm hidden-xs" title="home" role="button">
            <i class="fa fa-angle-up"></i>
        </a>

    </footer>
    <!-- Footer Ends -->

        <!-- JQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="js/bootstrap/bootstrap.min.js"></script>

    <script type="text/javascript" src="js/style.js"></script>

</body>
</html>